
Template for TRAX semestral work.

Overview:

- Implement your player to player.py file. No other modules/files than player.py will be accepted by Brute.
- test the game:

python3 player.py

- you can use class Drawer in draw.py that will pain the game into .png files.
- install PILLOW library ( https://pillow.readthedocs.io/en/stable/ )
- Drawer class needs access to tiles/ directory, be sure that your PyCharm/VSCode/etc.. are switching to this directory



