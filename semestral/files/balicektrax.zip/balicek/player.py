
import draw as Drawer
import sys
import random
import copy
import base as Base

# implement you player here. If you need to define some classes, do it also here. Only this file is to be submitted to Brute.
# define all functions here

class Player(Base.BasePlayer):
    def __init__(self, board, name, color):
        Base.BasePlayer.__init__(self,board, name, color)        
        self.algorithmName = "My great player"

    def move(self):
        """ return list of moves:
            []  ... if the player cannot move
            [ [r1,c1,piece1], [r2,c2,piece2] ... [rn,cn,piece2] ] -place tiles to positions (r1,c1) .. (rn,cn)
        """   
        return []


if __name__ == "__main__":
# call you functions from this block:

    boardRows = 10
    boardCols = boardRows
    board = [ ["none"]*boardCols for _ in range(boardRows) ]

    board[boardRows//2][boardCols//2] = ["lldd","dlld","ddll","lddl","dldl","ldld"][ random.randint(0,5) ]
    
    d = Drawer.Drawer()

    p1 = Player(board,"player1", 'l'); 
    p2 = Player(board,"player2", 'd');

    #test game. We assume that both player play correctly. In Brute/Tournament case, more things will be checked
    #like types of variables, validity of moves, etc...

    idx = 0
    while True:

        #call player for his move
        rmove = p1.move()

        #rmove is: [ [r1,c1,tile1], ... [rn,cn,tile] ]
        #write to board of both players
        for move in rmove:
            row,col, tile = move
            p1.board[row][col] = tile
            p2.board[row][col] = tile

        #make png with resulting board
        d.draw(p1.board, "move-{:04d}.png".format(idx))
        idx+=1

        if len(rmove) == 0:
            print("End of game")
            break
        p1,p2 = p2,p1  #switch players




